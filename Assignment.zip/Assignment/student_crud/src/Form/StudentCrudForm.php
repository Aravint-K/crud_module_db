<?php

namespace Drupal\student_crud\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Messenger;
use Drupal\Core\Link;

class StudentCrudForm extends FormBase {

  public function getFormId() {
    return 'student_crud_student_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $conn = Database::getConnection();
    $record = [];

    if ($sid = $form_state->get('sid')) {
      $query = $conn->select('student_crud_student', 's')
        ->condition('sid', $sid)
        ->fields('s');
      $record = $query->execute()->fetchAssoc();
    }

    $form['student_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Student Name'),
      '#required' => TRUE,
      '#default_value' => isset($record['student_name']) ? $record['student_name'] : '',
    ];
    $form['sub_id'] = [
      '#type' => 'number',
      '#title' => $this->t('Sub ID'),
      '#required' => TRUE,
      '#default_value' => isset($record['sub_id']) ? $record['sub_id'] : '',
    ];
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#required' => TRUE,
      '#default_value' => isset($record['email']) ? $record['email'] : '',
    ];
    $form['phone'] = [
      '#type' => 'tel',
      '#title' => $this->t('Phone'),
      '#required' => TRUE,
      '#default_value' => isset($record['phone']) ? $record['phone'] : '',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
    ];
    
    $subject_button = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#url' => Url::fromRoute('my_listing_module.admin_page'),
      '#attributes' => ['class' => ['button']],
    ];
    $form['actions']['cancel'] = $subject_button;
    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $conn = Database::getConnection();

    $subQuery = $conn->select('subject_crud_subject', 's');
    $subQuery->fields('s', ['sub_id']);
    $subResult = $subQuery->execute()->fetchAll();

    $flag = 0;

    foreach ($subResult as $subValue) {      
      if ($values['sub_id'] == $subValue->sub_id) {
        $flag = 1;
      }
    }
      
    if ($flag == 1) {
      if ($sid = $form_state->get('sid')) {
        $conn->update('student_crud_student')
          ->fields([
            'student_name' => $values['student_name'],
            'sub_id' => $values['sub_id'],
            'email' => $values['email'],
            'phone' => $values['phone'],
          ])
          ->condition('sid', $sid)
          ->execute();
        $this->messenger()->addMessage($this->t('Student updated successfully.'));
      } else {
        $conn->insert('student_crud_student')
          ->fields([
            'student_name' => $values['student_name'],
            'sub_id' => $values['sub_id'],
            'email' => $values['email'],
            'phone' => $values['phone'],
          ])
          ->execute();
        $this->messenger()->addMessage($this->t('Student added successfully.'));
      }
    } else {
      $this->messenger()->addMessage($this->t('Subject Id does not exist. Please add valid subject'));
    }

    $form_state->setRedirect('my_listing_module.admin_page');
  }

 
}
