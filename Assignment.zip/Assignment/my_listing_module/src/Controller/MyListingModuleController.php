<?php

namespace Drupal\my_listing_module\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;
use Drupal\Core\Link;
use Drupal\Core\Messenger;

class MyListingModuleController extends ControllerBase {

  public function adminPage() {
    $build = [];

    $subject_button = [
      '#type' => 'link',
      '#title' => $this->t('Add Subjects'),
      '#url' => Url::fromRoute('my_listing_module.subject_list'),
      '#attributes' => ['class' => ['button']],
    ];

    $student_button = [
      '#type' => 'link',
      '#title' => $this->t('Add Students'),
      '#url' => Url::fromRoute('my_listing_module.student_list'),
      '#attributes' => ['class' => ['button']],
    ];

    $build['subject_button'] = $subject_button;
    $build['student_button'] = $student_button;

    $header_table = [
      'sid' => t('SID'),
      'student_name' => t('Student Name'),
      'sub_id' => t('Sub ID'),
      'email' => t('Email'),
      'phone' => t('Phone'),
    ];
    $rows = [];

    $conn = Database::getConnection();
    $query = $conn->select('student_crud_student', 's');
    $query->fields('s', ['sid', 'student_name', 'sub_id', 'email', 'phone']);
    
    $result = $query->execute()->fetchAll();

    foreach ($result as $value) {

      $rows[] = [
        'sid' => $value->sid,
        'student_name' => $value->student_name,
        'sub_id' => $value->sub_id,
        'email' => $value->email,
        'phone' => $value->phone,
      ];
    }

    $table = [
      '#type' => 'table',
      '#header' => $header_table,
      '#rows' => $rows,
      '#empty' => $this->t('No records found'),
      
    ];
    $build['table'] = $table;

    $header_table2 = [
      'sub_id' => t('Sub ID'),
      'subject_name' => t('Subject Name'),
      'department_name' => t('Department Name'),

    ];
    $rows2 = [];

    $conn2 = Database::getConnection();
    $query2 = $conn2->select('subject_crud_subject', 's');
    $query2->fields('s', ['sub_id', 'subject_name', 'department_name']);
    $result2 = $query2->execute()->fetchAll();

    foreach ($result2 as $value2) {

      $rows2[] = [
        'sub_id' => $value2->sub_id,
        'subject_name' => $value2->subject_name,
        'department_name' => $value2->department_name,
      ];
    }

    $data2 = [
      '#type' => 'table',
      '#header' => $header_table2,
      '#rows' => $rows2,
      '#empty' => $this->t('No records found'),
    ];

    $build['Subject Table']=$data2;

    return $build;
  }

  public function redirectToStudentList() {
    return $this->redirect('student_crud.add');
  }

  public function redirectToSubjectList() {
    return $this->redirect('subject_crud.add');
  }

}
