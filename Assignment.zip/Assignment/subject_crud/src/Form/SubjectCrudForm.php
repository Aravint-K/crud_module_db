<?php

namespace Drupal\subject_crud\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Messenger;
use Drupal\Core\Link;

class SubjectCrudForm extends FormBase {

  public function getFormId() {
    return 'subject_crud_subject_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $sub_id = NULL) {
    $conn = Database::getConnection();
    $record = [];

    if ($sub_id) {
      $query = $conn->select('subject_crud_subject', 's')
        ->condition('sub_id', $sub_id)
        ->fields('s');
      $record = $query->execute()->fetchAssoc();
    }

    $form['subject_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Subject Name'),
      '#required' => TRUE,
      '#default_value' => isset($record['subject_name']) ? $record['subject_name'] : '',
    ];
    
    $form['department_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Department Name'),
      '#required' => TRUE,
      '#default_value' => isset($record['department_name']) ? $record['department_name'] : '',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
    ];

    if ($sub_id) {
      $form['actions']['delete'] = [
        '#type' => 'submit',
        '#value' => $this->t('Delete'),
        '#submit' => ['::deleteSubject'],
      ];
    }

    $subject_button = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#url' => Url::fromRoute('my_listing_module.admin_page'),
      '#attributes' => ['class' => ['button']],
    ];
    $form['actions']['cancel'] = $subject_button;

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    // Add validation logic here if needed.
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $conn = Database::getConnection();

    if ($sub_id = $form_state->get('sub_id')) {
      $conn->update('subject_crud_subject')
        ->fields([
          'subject_name' => $values['subject_name'],
          'department_name' => $values['department_name'],
        ])
        ->condition('sub_id', $sub_id)
        ->execute();
      $this->messenger()->addMessage($this->t('Subject updated successfully.'));
    } else {
      $conn->insert('subject_crud_subject')
        ->fields([
          'subject_name' => $values['subject_name'],
          'department_name' => $values['department_name'],
        ])
        ->execute();
      $this->messenger()->addMessage($this->t('Subject added successfully.'));
    }

    $form_state->setRedirect('my_listing_module.admin_page');
  }


}
